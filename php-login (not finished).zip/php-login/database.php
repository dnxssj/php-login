<?php 

$server = 'localhost';
$username = 'root';
$password =   '';
$database = 'php_login_db';

try {
    $conn = new PDO("mysql:host=$server;dbname=$database;", $username, $password);
} catch (PDOException $err) {
    die('Connection failed: '. $err->getMessage());
}
?>