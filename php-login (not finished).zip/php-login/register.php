<?php
    require 'database.php';

    $message = '';


    if (!empty($_POST['name'] && !empty($_POST['email'] && !empty($_POST['password'])) {
        $sql = "INSERT INTO users (user, email, password) VALUES (:user, :email, :password)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':user',$_POST['user']);
        $stmt->bindParam(':email',$_POST['email']);
        $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
        $stmt->bindParam(':password', $password);

        if ($stmt->execute()) {
            $message = 'New user successfully created';
        } else {
            $message = 'Sorry, there is a problem creating your user';
        }
        
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DNX - Register</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    

    <?php require 'partials/header.php' ?>

    <?php if(!empty($message)): ?>
        <p><?= $message ?></p>
        <?php endif; ?>



        <h1>Register</h1>
        
        <form action="register.php" method="post">
        <input type="text" name="user" placeholder="Enter your Nickname">
        <input type="text" name="email" placeholder="Enter your E-Mail">
        <input type="password" name="password" placeholder="Enter your password">
        <input type="password" name="confirm_password" placeholder="Confirm your password">
        <input type="submit" value="Send">
        </form>

        <span>or <a href="login.php">Login</a></span>

</body>
</html>